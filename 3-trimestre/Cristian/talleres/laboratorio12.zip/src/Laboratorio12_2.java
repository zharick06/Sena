import javax.swing.JOptionPane;
public class Laboratorio12_2 {
	///con metodos
		public static void main(String[] args) {
			///se crean las variables
			double ladoA;
			double ladoB;
			
			///se le asigna un valor
			ladoA=ingresarDatos("Ingrese la longitud de A: ");
			ladoB=ingresarDatos("Ingrese la longitud de B: ");
			
			calcularArea(ladoA,  ladoB);
			
		}
		//se crea un metodo para asignarle valor
		public static double ingresarDatos (String mensaje) {
			///se crean las variables
			String cadena;
			double valor;
			///se imprime el mensaje
			 cadena=JOptionPane.showInputDialog(null,mensaje);
			 ///se le asigan un valor a valor
			 valor=Double.parseDouble(cadena);
			 ///se retorna el valor
			 return valor;
			 
		}
		//se crea un metodo para calcular el area
		public static void calcularArea (double a, double b) {
			///se crea la variable
			double resultado;
			///se hace la operacion
			resultado= a *b;
			///se imprime el resultado
			JOptionPane.showMessageDialog(null,"El resultado es: "+ resultado);
			
		}

}
