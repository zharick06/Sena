import javax.swing.JOptionPane;

public class Laboratorio12_1 {
	///sin metodos
public static void main(String[] args) {
		///se crean las variables
		String cadena;
		double ladoA;
		double ladoB;
		double resultado;
		
		///se le asigna un valor a lado A
		 cadena=JOptionPane.showInputDialog(null,"Ingrese la longitud de A: ");
		 ladoA=Double.parseDouble(cadena);
		///se le asigna un valor a lado B
		 cadena=JOptionPane.showInputDialog(null,"Ingrese la longitud de B: ");
		 ladoB=Double.parseDouble(cadena);
		 ///se hace la operacion
		 resultado=ladoA * ladoB;
		 ///se imprime el resultado
		 JOptionPane.showMessageDialog(null,"El resultado es: " + resultado);
		 
		 
		 
	}
}
