import javax.swing.JOptionPane;
public class Entidad {
	///se crean las variables privadas
	private double ladoA;
	private double ladoB;
	
	//se crea un metodo para asignarle valor
	public void ingresarDatos() {
		///se crea la variable
		String cadena;
		///se le asigna un valor a lado A
		 cadena=JOptionPane.showInputDialog(null,"Ingrese la longitud de A: ");
		 ladoA=Double.parseDouble(cadena);
		///se le asigna un valor a lado B
		 cadena=JOptionPane.showInputDialog(null,"Ingrese la longitud de B: ");
		 ladoB=Double.parseDouble(cadena); 
	}	
	//se crea un metodo para calcular el area
	public void calcularArea() {
		///se crea la variable
		double resultado;
		///se hace la operacion
		resultado=ladoA * ladoB;
		///se imprime el resultado
		 JOptionPane.showMessageDialog(null,"El resultado es: " + resultado);
		
	}

}
