
public class Aplicacion {
	//se crea clase para poder trabajar con objetos no estáticos.
	public static void main(String[] args) {
		//se crea el objeto
		Entidad rectangulo;
		//se crea el constructor para crear las instacias
		rectangulo= new Entidad();
		rectangulo.ingresarDatos();
		rectangulo.calcularArea();	
	}

}
