import Ventanas.VentanaPrincipal;

public class Principal {

	public static void main(String[] args) {
		VentanaPrincipal miVenta=new VentanaPrincipal();
		miVenta.setVisible(true);
	}

}
