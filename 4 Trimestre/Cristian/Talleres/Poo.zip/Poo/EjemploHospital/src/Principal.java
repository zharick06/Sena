
public class Principal {
	public static void main(String[] args) {
		Procesos misProcesos=new Procesos();
		
	}

}
