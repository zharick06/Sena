package ManejoColorespropiedades;

public class Principal {

	public static void main(String[] args) {
		VentanaPrincipal miventana=new VentanaPrincipal();
		miventana.setVisible(true);

	}

}
