package DesactivarComponentesGráficos;

public class Principal {

	public static void main(String[] args) {
		VentanaPrincipal miVentana = new VentanaPrincipal();
		miVentana.setVisible(true);

	}

}
