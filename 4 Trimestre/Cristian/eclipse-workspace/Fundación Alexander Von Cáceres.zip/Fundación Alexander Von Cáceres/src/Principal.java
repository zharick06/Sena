import Interfaces.VentanaEventos;

public class Principal {

	public static void main(String[] args) {
		VentanaEventos miVentanaEventos=new VentanaEventos();
		miVentanaEventos.setVisible(true);
		

	}

}
