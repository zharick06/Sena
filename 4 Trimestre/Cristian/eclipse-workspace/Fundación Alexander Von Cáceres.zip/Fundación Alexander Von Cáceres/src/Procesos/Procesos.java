package Procesos;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Procesos {
	ArrayList<Evento>listaEvento;
	
	public Procesos() {
		listaEvento=new ArrayList<Evento>();
				
	}

	public void registrarEvento(Evento miEvento) {
		System.out.println("Se registro evento");
		listaEvento.add(miEvento);
	
		
		
	}

	public void imprimirEventos() {
		if(listaEvento == null || listaEvento.size() == 0)
		{
			JOptionPane.showMessageDialog(null, "No hay eventos que mostrar \n ", "ERROR",JOptionPane.ERROR_MESSAGE);
		}
		else{
			for (Evento evento : listaEvento) {
				
				System.out.println(evento);
				
			}
		}
		
		
		
	}

	public Evento consultarEvento(String co) {
		Evento bus=null;
		for (Evento evento : listaEvento) {
			if (evento.getCodigo().equals(co)) {
				bus=evento;
				
			}
			
		}
		return bus;
	}


	}



	


