from Prueba import *

         
for i in range(100):
    print("Prueba:",str(i+1))
    prueba()
    print("*"*50)        