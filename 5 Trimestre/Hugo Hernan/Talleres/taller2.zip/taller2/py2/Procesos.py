

def Procesos(n1):
    par=n1%2  
    return(par)
           
            
    
   
  