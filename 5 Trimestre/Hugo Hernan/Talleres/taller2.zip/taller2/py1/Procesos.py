

def Procesos(n1,n2):
   
    hora=(n1 *3000) 
    minutos=(n2*50)
    pagar=hora + minutos  
    return(pagar)
           
            
    
   
  