from Prueba import *

         
for i in range(10):
    print("Prueba:",str(i+1))
    prueba()
    print("*"*50)        