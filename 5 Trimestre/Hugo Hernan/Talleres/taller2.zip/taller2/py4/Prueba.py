import random
from Procesos import *

def prueba():
    juan=random.randint(1,10)
    mario=random.randint(1,10)
    pedro=random.randint(1,10)
    llega=Procesos(juan,mario,pedro)
    
       

        
   
              
      
        
            
