

def Procesos(docenas):
    precio=12000
    total=docenas*precio
    if docenas > 3:
        descuento=0.15*total
        totalpagar=total-descuento
        return(totalpagar)
    else:
        descuento=0.15*total
        totalpagar=total-descuento
        return(totalpagar)
            
  
           
            
    
   
  