import logo from './logo.svg';
import './App.css';
import { Pagina } from './Components/Page/Pagina';

function App() {
  return (
    <div className="App">
     <Pagina/>
  
    </div>
  );
}

export default App;
