package laboratorio13;

import javax.swing.JOptionPane;

public class Flecha {
	///definimos las variables
	int longitud;
	String color;
	
	public Flecha() {
		//les asignamos el  valor
		longitud=Integer.parseInt(JOptionPane.showInputDialog("Ingrese la longitud"));
		color=JOptionPane.showInputDialog("Ingrese el color");		
	}
	
	public  Flecha(int longitud,String color) {
		this.longitud=longitud;
		this.color=color;
		
	}
	public void imprimirEspacio() {
		System.out.println();
		
	}
	public void contruirFlecha() {
		//construimos la flecha
		for (int i = 0; i < longitud; i++) {
			imprime("_");
		}
		imprime(">");
	}
	
	private void imprime(String simbolo) {
		//si el color es negro saldra negro
		if (color.equals("negro")) {
			System.out.println(simbolo);
		}
		//si no saldra del color rojo de error
		else {
			System.err.println(simbolo);
		}
		
	}

}
