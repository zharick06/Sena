package laboratorio13;

public class Principal {
	//se crea los objetos
	Flecha flecha1, flecha2, flecha3; 	
	//se crea clase para poder trabajar con objetos no estáticos.
	public static void main(String[] args) {
		Principal miPrincipal=new Principal();
		}
    public Principal() { 
    	//se crea el constructor para crear las instacias
    	flecha1=new Flecha();
    	flecha1.contruirFlecha();
    	flecha1.imprimirEspacio();
		
    	//se crea el constructor para crear las instacias
    	flecha2=new Flecha();
    	flecha2.contruirFlecha();
    	flecha2.imprimirEspacio();
    	
    	
    	//se crea el constructor para crear las instacias 
    	flecha3=new Flecha();
    	flecha3.contruirFlecha();
    	flecha3.imprimirEspacio();
	}

}
